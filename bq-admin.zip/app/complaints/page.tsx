"use client";

import { useState, useEffect } from "react";
import { AdminHeader } from "@/components/admin/admin-header";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Search,
  Trash2,
  Download,
  MessageSquareWarning,
  Eye,
} from "lucide-react";
import { apiClient, type Complaint } from "@/lib/api";
import { toast } from "@/hooks/use-toast";

export default function ComplaintsPage() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("createdDate");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(
    null
  );
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  useEffect(() => {
    console.log("sdfsdfsdf");
    loadComplaints();
  }, []);

const loadComplaints = async () => {
  console.log("Loading complaints...");
  try {
    setIsLoading(true);
    const data = await apiClient.getComplaints(); 
    console.log("Complaints data received:", data);
    
    // Проверка структуры данных
    if (Array.isArray(data)) {
      console.log("Data is array, length:", data.length);
      setComplaints(data);
    } else {
      console.error("Expected array but got:", typeof data, data);
      setComplaints([]);
    }
  } catch (error) {
    console.error("Error loading complaints:", error);
    toast({
      title: "Ошибка",
      description: "Не удалось загрузить жалобы",
      variant: "destructive",
    });
    setComplaints([]);
  } finally {
    setIsLoading(false);
  }
};

  console.log(complaints, "complaints");

  // Filter and sort complaints
  const filteredComplaints = complaints
    .filter(
      (complaint) =>
        complaint.description
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        complaint.id.toString().includes(searchTerm) ||
        complaint.service_id.toString().includes(searchTerm) ||
        complaint.user_id.toString().includes(searchTerm)
    )
    .sort((a, b) => {
      switch (sortBy) {
        case "createdDate":
          return (
            new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
          );
        case "id":
          return b.id - a.id;
        case "serviceId":
          return b.service_id - a.service_id;
        case "userId":
          return b.user_id - a.user_id;
        default:
          return 0;
      }
    });

  const handleDelete = async (id: number) => {
    try {
      await apiClient.deleteComplaint(id);
      setComplaints(complaints.filter((complaint) => complaint.id !== id));
      toast({
        title: "Успешно",
        description: "Жалоба удалена",
      });
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось удалить жалобу",
        variant: "destructive",
      });
    }
  };

  const handleViewComplaint = (complaint: Complaint) => {
    setSelectedComplaint(complaint);
    setIsDetailsOpen(true);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ru-RU", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#efefef]">
        <AdminHeader />
        <div className="flex">
          <AdminSidebar />
          <main className="flex-1 p-6 ml-64 mt-18">
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#aa0400] mx-auto"></div>
                <p className="mt-2 text-sm text-gray-600">Загрузка жалоб...</p>
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#efefef]">
      <AdminHeader />
      <div className="flex">
        <AdminSidebar />
        <main className="flex-1 p-6 ml-64 mt-18">
          <div className="max-w-7xl mx-auto">

            {/* Controls */}
            <div className="bg-white rounded-lg p-6 mb-6">
              <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
                <div className="flex flex-col sm:flex-row gap-4 flex-1">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Поиск по описанию или ID..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Сортировать по" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="createdDate">
                        По дате создания
                      </SelectItem>
                      <SelectItem value="id">По ID жалобы</SelectItem>
                      <SelectItem value="serviceId">По ID услуги</SelectItem>
                      <SelectItem value="userId">По ID пользователя</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Complaints Table */}
            <div className="bg-white rounded-lg overflow-hidden">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>ID Услуги</TableHead>
                      <TableHead>ID Пользователя</TableHead>
                      <TableHead>Описание</TableHead>
                      <TableHead>Дата создания</TableHead>
                      <TableHead className="text-right">Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredComplaints.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          {searchTerm ? "Жалобы не найдены" : "Нет жалоб"}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredComplaints.map((complaint) => (
                        <TableRow key={complaint.id}>
                          <TableCell className="font-medium">
                            #{complaint.id}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              #{complaint.service_id}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">
                              #{complaint.user_id}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-xs">
                            <div
                              className="truncate"
                              title={complaint.description}
                            >
                              {complaint.description}
                            </div>
                          </TableCell>
                          <TableCell>
                            {formatDate(complaint.created_at)}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleViewComplaint(complaint)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>
                                      Удалить жалобу?
                                    </AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Это действие нельзя отменить. Жалоба будет
                                      удалена навсегда.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>
                                      Отмена
                                    </AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDelete(complaint.id)}
                                      className="bg-red-600 hover:bg-red-700"
                                    >
                                      Удалить
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>

            {/* Stats */}
            <div className="mt-6 bg-white rounded-lg p-4">
              <div className="flex items-center justify-between text-sm text-gray-600">
                <span>
                  Показано {filteredComplaints.length} из {complaints.length}{" "}
                  жалоб
                </span>
                <div className="flex items-center gap-2">
                  <MessageSquareWarning className="h-4 w-4" />
                  <span>Всего жалоб: {complaints.length}</span>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Complaint Details Modal */}
      {selectedComplaint && (
        <AlertDialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
          <AlertDialogContent className="max-w-2xl">
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <MessageSquareWarning className="h-5 w-5 text-[#aa0400]" />
                Детали жалобы #{selectedComplaint.id}
              </AlertDialogTitle>
            </AlertDialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">
                    ID Услуги
                  </label>
                  <p className="text-sm">#{selectedComplaint.service_id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">
                    ID Пользователя
                  </label>
                  <p className="text-sm">#{selectedComplaint.user_id}</p>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">
                  Дата создания
                </label>
                <p className="text-sm">
                  {formatDate(selectedComplaint.created_at)}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">
                  Описание жалобы
                </label>
                <p className="text-sm bg-gray-50 p-3 rounded-md">
                  {selectedComplaint.description}
                </p>
              </div>
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel>Закрыть</AlertDialogCancel>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
