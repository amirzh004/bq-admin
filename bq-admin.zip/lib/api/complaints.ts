import { BaseApiClient } from "./base"
import type { Complaint } from "@/lib/types/models"
import { API_CONFIG } from "@/lib/config/api"

export class ComplaintsApiClient extends BaseApiClient {
  async getComplaints(): Promise<Complaint[]> {
    // Временно используем прямой URL для тестирования
    const testUrl = "http://89.35.125.132:4001/complaints";
    console.log('Testing direct URL:', testUrl);
    
    try {
      const response = await fetch(testUrl);
      console.log('Direct fetch status:', response.status);
      const text = await response.text();
      console.log('Direct fetch response:', text);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return JSON.parse(text);
    } catch (error) {
      console.error('Direct fetch failed:', error);
      throw error;
    }
  }
  async deleteComplaint(id: number): Promise<void> {
    await this.request(`${API_CONFIG.ENDPOINTS.COMPLAINTS.DELETE}/${id}`, {
      method: "DELETE",
    })
  }
}

export const complaintsApi = new ComplaintsApiClient()
