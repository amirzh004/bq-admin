export const API_CONFIG = {
  BASE_URL: process.env.NODE_ENV === 'production' 
    ? "http://89.35.125.132:4001" 
    : "",
  TIMEOUT: 10000,
  RETRY_ATTEMPTS: 3,
  COOKIE_NAMES: {
    ACCESS_TOKEN: "accessToken",
    REFRESH_TOKEN: "refreshToken",
    ADMIN_SESSION: "admin-session",
  },
  ENDPOINTS: {
    AUTH: {
      SIGN_IN: "/user/sign_in",
    },
    USERS: {
      GET_ALL: "/user",
      DELETE: "/user",
    },
    ADMIN: {
      SERVICES: {
        GET_ALL: "/admin/service/get",
        DELETE: "/service",
      },
      SERVICES_AD: {
        GET_ALL: "/admin/service_ad/get",
        DELETE: "/ad",
      },
      WORK: {
        GET_ALL: "/admin/work/get",
        DELETE: "/work",
      },
      WORK_AD: {
        GET_ALL: "/admin/work_ad/get",
        DELETE: "/work_ad",
      },
      RENT: {
        GET_ALL: "/admin/rent/get",
        DELETE: "/rent",
      },
      RENT_AD: {
        GET_ALL: "/admin/rent_ad/get",
        DELETE: "/rent_ad",
      },
    },
    COMPLAINTS: {
      GET_ALL: "/complaints",
      DELETE: "/complaints",
    },
  },
} as const